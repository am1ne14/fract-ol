#include "../inc/minishell.h"

int    preprocess_line(char *line)
{
    line = trim_white_spaces(line);

    if (check_invalid_start(line))
    {
        printf("Error: Invalid syntax near '%c'\n", line[0]);
        return (1); 
    }
    if (check_unclosed_quotes(line))
    {
        printf("Error: unclosed quotes in input\n");
        return (1);
    }
    if (check_consecutive_operators(line))
    {
        printf("Error: Invalid syntax - consecutive operators found\n");
        return (1);
    }

    return (0);
}

char    *trim_white_spaces(char *str)
{
    char    *end;

    while (*str == ' ')
        str++;
    if (*str == '\0')
        return (str);
    end = str + strlen(str) - 1; //strlen !!
    while (end > str && *end == ' ')
        end--;

    if (*end == '|' || *end == '>' || *end == '<') // ghi mlb9a
    {
        printf("Syntax error");
        exit(EXIT_FAILURE);
    }
 
 
    *(end + 1) = 0;
    return (str);
}

int check_invalid_start(char *line)
{
    if (line[0] == '|' || line[0] == '<' || line[0] == '>')
        return (1);
    while (*line)
        line++;   
    return (0);
}

int    check_unclosed_quotes(char *line)
{
    char    quote;

    quote = '\0';
    while (*line)
    {
        if ((*line == '\'' || *line == '\"') && quote == '\0')
            quote = *line;
        else if (*line == quote)
            quote = '\0';
        line++;
    }
    return (quote != '\0');
}

int    check_consecutive_operators(char *line)
{
    while (*line)
    {
        if ((*line == '|' || *line == '<' || *line == '>' ) &&
        (*(line + 1) == '|' || *(line + 1) == '>' || *(line + 1) == '<'))
        {
            return (1);
        }
        line++;
    }
    return (0);
}