#include "../../incs/minishell.h"

static int	word_count(const char *s, char delimiter)
{
	int	count;
	bool	in_word;

	count = 0;
	in_word = false;
	while (*s)
	{
		if (*s != delimiter && !in_word)
		{
			in_word = true;
			count++;
		}
		else if (*s == delimiter)
			in_word = false;
		s++;
	}
	return (count);
}

// Allocate a substring from start to end
static char	*allocate_word(const char *start, const char *end)
{
	char	*word;
	int		length;
	int		i;

	length = end - start;
	word = malloc(sizeof(char) * (length + 1));
	if (!word)
		return (NULL);
	i = 0;
	while (start < end)
		word[i++] = *start++;
	word[i] = '\0';
	return (word);
}

// Free allocated memory for split array on failure
static void	free_split(char **split, int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		free(split[i]);
		i++;
	}
	free(split);
}

// Split the string into substrings based on the delimiter
char	**ft_split(const char *s, char delimiter)
{
	char	**result;
	const char	*start;
	int		i;

	if (!s)
		return (NULL);
	result = malloc(sizeof(char *) * (word_count(s, delimiter) + 1));
	if (!result)
		return (NULL);
	i = 0;
	while (*s)
	{
		if (*s != delimiter)
		{
			start = s;
			while (*s && *s != delimiter)
				s++;
			result[i] = allocate_word(start, s);
			if (!result[i++])
			{
				free_split(result, i - 1);
				return (NULL);
			}
		}
		else
			s++;
	}
	result[i] = NULL;
	return (result);
}