#ifndef MINI_SHELL_H
#define MINI_SHELL_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h>
#include <signal.h>
#include <readline/readline.h>
#include <readline/history.h>


    //struct for every single envirement variable
typedef struct s_env
{
    char        *key;       //name of the env variable
    char        *value;     //value of  ^^
    struct s_env    *next;  //point to next env variable (linked list)
}   t_env;


    //struct to parse commands and its arguments
typedef struct  s_command
{
    char **argv;            
    char    **cmp_path;         // full path of the executable binary of the command inputed 
    int     input_fd;           // (redirection)
    int     output_fd;          //    --
    struct s_command *next;     //pointer of the next argument if they use | (linked list)
}   t_command;


// main struct for the whole shell session 
typedef struct s_shell
{
    t_env   *env;               //linked llist of the env variables
    t_command   *command_list;  //linked list of the parsed commands
    bool    is_running;         // is the shell still running 
    int     last_exit_code;     // exit_code of the last runned command
}   t_shell;


//signals
void    signals_handeling(void);
void    sigint_handler(int sig);
void    sigsegv_handler(int sig);
void    sigabrt_handler(int sig);
void	clear_rl_line(void);

//  init_stuff
void    init_data(t_shell *data);
t_env*   init_env(char **env);



#endif
