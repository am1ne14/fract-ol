#include "../../incs/minishell.h"
/*
t_command   *parse_commands(char **tokens, t_env *env);
t_command   *create_command_node(void);
t_command	*create_next_command(t_command *current, int *i);
void	    process_token(t_command *cmd, char **tokens, int *i, t_env *env);

*/

t_command *parse_commands(char **tokens, t_env *env)
{
    t_command   *head;
    t_command   *current;
    int         i;

    i = 0;
    head = NULL;
    current = NULL;
    while (tokens)
    {
        if (!head)
            head = create_command_node();
            else if (is_pipe(tokens[i]))
                current = create_next_command(current, &i);
            else
                process_token(current, tokens, &i, env);
    }
    return (head);
}

t_command   *create_command_node(void)
{
    t_command   *cmd;

    cmd = (t_command *)malloc(sizeof(t_command));
    if (!cmd)
        return (NULL);
    cmd->argv = NULL;
    cmd->cmd_path = NULL;
    cmd->input_fd = STDIN_FILENO;
    cmd->output_fd = STDOUT_FILENO;
    cmd->next = NULL;
    return (cmd);
}

t_command	*create_next_command(t_command *current, int *i)
{
	current->next = create_command_node();
	*i += 1;
	return (current->next);
}

void	process_token(t_command *cmd, char **tokens, int *i, t_env *env)
{
	if (is_redirection(tokens[*i]))
		handle_redirection(cmd, tokens, i);
	else
        add_argument(cmd, tokens[*i], env);
}

void	handle_redirection(t_command *cmd, char **tokens, int *i)
{
	if (!tokens[*i + 1])
	{
		printf("minishell: syntax error near unexpected token\n"    );
		return ;
	}
	if (strcmp(tokens[*i], ">") == 0)
	{
		if (cmd->output_fd != STDOUT_FILENO)
			close(cmd->output_fd);
		cmd->output_fd = open(tokens[*i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (cmd->output_fd == -1)
			perror("minishell");
	}
	else if (strcmp(tokens[*i], ">>") == 0)
	{
		if (cmd->output_fd != STDOUT_FILENO)
			close(cmd->output_fd);
		cmd->output_fd = open(tokens[*i + 1], O_WRONLY | O_CREAT | O_APPEND, 0644);
		if (cmd->output_fd == -1)
			perror("minishell");
	}
	else if (strcmp(tokens[*i], "<") == 0)
	{
		if (cmd->input_fd != STDIN_FILENO)
			close(cmd->input_fd);
		cmd->input_fd = open(tokens[*i + 1], O_RDONLY);
		if (cmd->input_fd == -1)
			perror("minishell");
	}
	*i += 2;
}