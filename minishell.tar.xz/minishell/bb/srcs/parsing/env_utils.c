#include "../../incs/minishell.h"
/*
void	add_argument(t_command *cmd, char *token, t_env *env);
char	*expand_env_var(char *token, t_env *env)
char	*get_env_value(t_env *env, const char *key)
char	*get_key(const char *token)

*/

void	add_argument(t_command *cmd, char *token, t_env *env)
{
	char	*expanded;

	expanded = expand_env_var(token, env);
	cmd->argv = add_to_array(cmd->argv, expanded);
	free(expanded);
}

char	*expand_env_var(char *token, t_env *env)
{
	char	*key;

	if (!token || token[0] != '$')
		return (strdup(token));
	key = get_key(token + 1);
	return (get_env_value(env, key));
}

char	*get_env_value(t_env *env, const char *key)
{
	while (env)
	{
		if (strcmp(env->key, key) == 0)
			return (strdup(env->value));
		env = env->next;
	}
	return (strdup(""));
}

char	*get_key(const char *token)
{
	int		len;
	char	*key;

	len = 0;
	while (token[len] && ft_isalnum(token[len])) //!!
		len++;
	key = malloc(sizeof(char) * (len + 1));
	if (!key)
		return (NULL);
	ft_strlcpy(key, token, len + 1);
	return (key);
}
