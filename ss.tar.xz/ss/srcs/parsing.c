#include "../inc/minishell.h"

int    parse_line(t_shell *data, char *line)
{
    char    **tokens;

    // preprocesse (validate syntax and remouve white spaces)
    if (preprocess_line(line))
        return (1);

    //tokenize the input into an array of tokens
    tokens = tokenize(line);
    if (!tokens)
        return (1);
    
    //build a linked list of commands from the token
    if (build_command_list(data, tokens))
    {
        free_tokens(tokens);
        return (1);
    }
    // re check the parsed commands
    if (validate_command_list(data->command_list))
    {
        free_tokens(tokens);
        free_command_list(data->command_list);
        return (1);
    }
    free_tokens(tokens);
    return (0);
}

int build_command_list(data, tokens)
{

}
int validate_command_list(t_command *cmd_list)
{

}