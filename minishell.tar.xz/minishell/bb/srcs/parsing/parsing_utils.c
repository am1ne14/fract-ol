#include "../../incs/minishell.h"

/*
char    *trim_white_spaces(char *str);
int     array_size(char **array);
int     is_special_char(char c);
int is_pipe(char *token);
int	is_redirection(char *token);
char	**add_to_array(char **array, char *str);

*/
//preprocessing.c
char    *trim_white_spaces(char *str)
{
    char    *end;

    while (*str == ' ')
        str++;
    if (*str == '\0')
        return (str);
    end = str + strlen(str) - 1;
    while (end > str && *end == ' ')
        end--;
    *(end + 1) = 0;
    return (str);
}

//tokenize.c
int	array_size(char **array)
{
	int		size;

	size = 0;
	while (array && array[size])
		size++;
	return (size);
}

int	is_special_char(char c)
{
	return (c == '|' || c == '<' || c == '>' || c == '&' || c == ';');
}

//parse_command.c
int is_pipe(char *token)
{
    if (!token) 
        return (0);
    return (token[0] == '|' && token[1]=='\0');
}

int	is_redirection(char *token)
{
	return (!strcmp(token, ">") || !strcmp(token, ">>") || !strcmp(token, "<"));
}

char	**add_to_array(char **array, char *str)
{
	char	**new_array;
	int		i;

	i = 0;
	while (array && array[i])
		i++;
	new_array = (char **)malloc(sizeof(char *) * (i + 2));
	if (!new_array)
		return (NULL);
	i = 0;
	while (array && array[i])
	{
		new_array[i] = array[i];
		i++;
	}
	new_array[i] = strdup(str);
	new_array[i + 1] = NULL;
	free(array);
	return (new_array);
}

int	ft_isalnum(int c)
{
	if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
		|| (c >= '0' && c <= '9'))
		return (1);
	return (0);
}

size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
	size_t	i;

	if (!dst || !src)
		return (0);
	i = 0;
	while (src[i] && i + 1 < dstsize)
	{
		dst[i] = src[i];
		i++;
	}
	if (dstsize > 0)
		dst[i] = '\0';
	while (src[i])
		i++;
	return (i);
}