rm -rf minishell

cc -g main.c parsing/*.c signals/*.c utils/*.c -lreadline -o minishell

echo "AAAAAAAAAAAAAAAAAAAAAAAAAA"

./minishell
