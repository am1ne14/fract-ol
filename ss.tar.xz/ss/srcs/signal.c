#include "../inc/minishell.h"

void    signals_handeling(void)
{
    signal(SIGINT, &sigint_handler);   
    signal(SIGSEGV, &sigsegv_handler);
    signal(SIGABRT, &sigabrt_handler);
    signal(SIGQUIT, SIG_IGN);
}

void	clear_rl_line(void)
{
	rl_replace_line("", 0);
	rl_on_new_line();
}

void    sigint_handler(int sig)
{
    (void)sig;
    write(1,"\n", 1);
    clear_rl_line();
    rl_redisplay();    
}

void    sigsegv_handler(int sig)
{
	(void)sig;
	write(2, "Segmentation fault\n", 19);
	exit(EXIT_FAILURE);
}

void    sigabrt_handler(int sig)
{
	(void)sig;
	write(1, "abort\n", 6);
}