#ifndef	MINISHELL_H
#define MINISHELL_H


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h>
#include <signal.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "../libft/libft.h"


typedef struct s_env
{
    char        *key;
    char        *value;
    struct s_env    *next;
}   t_env;



typedef struct  s_command
{
    char    **argv;
    char    **cmd_path;
    int     input_fd;
    int     output_fd;
    struct s_command *next;
}   t_command;


typedef struct s_shell
{
    t_env           *env;
    t_command       *command_list;
    bool            is_running;
    int             last_exit_code;
}   t_shell;

//----init_data

void	init_shell(t_shell *data, char **env);
t_env	*create_env_list(char **env);

//---signals
void    signals_setup(void);
void    sigint_handler(int sig);
void    sigsegv_handler(int sig);
void    sigabrt_handler(int sig);
//----Parsing
int    parse_line(t_shell *data, char *line);
//preprocesse,c
int    preprocess_line(char *line);
int     check_invalid_start(char *line);
int    check_unclosed_quotes(char *line);
int    check_consecutive_operators(char *line);
//tokenize.c
char    **tokenize(char *line);
int     process_tokens(char **raw_tokens, char **tokens, int *i);
char    *remouve_quotes(char *token);

//utils
char *ft_strndup(const char *s, size_t n);
void	clear_rl_line(void);
char    *trim_white_spaces(char *str);
int     array_size(char **array);
int     is_special_char(char c);





void    print_array(char **token);
#endif
