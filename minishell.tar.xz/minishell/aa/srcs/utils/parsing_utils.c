#include "../../inc/minishell.h"
/*
char    *trim_white_spaces(char *str);
int     array_size(char **array);
int     is_special_char(char c);
int is_pipe(char *token);
int	is_redirection(char *token);
char	**add_to_array(char **array, char *str);

*/

char    *trim_white_spaces(char *str)
{
    char    *end;

    while (*str == ' ')
        str++;
    if (*str == '\0')
        return (str);
    end = str + strlen(str) - 1;
    while (end > str && *end == ' ')
        end--;
    *(end + 1) = 0;
    return (str);
}

int	array_size(char **array)
{
	int		size;

	size = 0;
	while (array && array[size])
		size++;
	return (size);
}

int	is_special_char(char c)
{
	return (c == '|' || c == '<' || c == '>' || c == '&' || c == ';');
}