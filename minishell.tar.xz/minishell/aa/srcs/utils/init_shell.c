#include "../../inc/minishell.h"

/*
void	init_shell(t_shell *data, char **env);
t_env	*create_env_list(char **env);

*/

void	init_shell(t_shell *data, char **env)
{
	data->env = create_env_list(env);
	data->command_list = NULL;
	data->is_running = 1;
	data->last_exit_code = 0;
	signals_setup();
}

t_env	*create_env_list(char **env)
{
	t_env	*head;
	t_env	*current;
	t_env	*new;
	int	i;

	head = NULL;
	current = NULL;
	i = 0;
	while (env[i])
	{
		new = (t_env *)malloc(sizeof(t_env));
		if (!new)
			return (NULL);
		new->key = ft_substr(env[i], 0, ft_strchr(env[i], '=') - env[i]);
		new->value = ft_strdup(ft_strchr(env[i], '=') + 1);
		new->next = NULL;
		if (!head)
			head = new;
		else
			current = new;
		i++;
	}
	return (head);
}
