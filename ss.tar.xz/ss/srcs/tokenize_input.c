#include "../inc/minishell.h"


int is_operator(char c)
{
    return (c == '|' || c == '<' || c == '>');
}


int add_token(t_tokenizer *t)
{
    if (t->buf_index == 0)
        return 0;

    t->buffer[t->buf_index] = '\0';
    t->tokens = realloc(t->tokens, sizeof(char *) * (t->token_count + 2));
    if (!t->tokens)
        return -1;

    t->tokens[t->token_count] = strdup(t->buffer);
    t->tokens[t->token_count + 1] = NULL;
    t->token_count++;
    t->buf_index = 0;
    return 0;
}

void handle_quote(t_tokenizer *t, char c)
{
    if (t->quote == '\0')
        t->quote = c;
    else if (t->quote == c)
        t->quote = '\0';
    else
        t->buffer[t->buf_index++] = c;
}

int handle_operator(t_tokenizer *t, char c)
{
    if (add_token(t) == -1)
        return -1;

    t->buffer[0] = c;
    t->buffer[1] = '\0';

    if (add_token(t) == -1)
        return -1;
    return 0;
}

int handle_space(t_tokenizer *t)
{
    return add_token(t);
}

void handle_escape(t_tokenizer *t, char c)
{
    t->buffer[t->buf_index++] = c;
}

char **tokenize(char *line)
{
    t_tokenizer t = {{0}, 0, NULL, 0, '\0'};
    int i = 0;

    while (line[i])
    {
        if ((line[i] == '\'' || line[i] == '\"'))
            handle_quote(&t, line[i]);
        else if (t.quote == '\0' && is_operator(line[i]))
        {
            if (handle_operator(&t, line[i]) == -1)
                return NULL;
        }
        else if (t.quote == '\0' && isspace(line[i]))
        {
            if (handle_space(&t) == -1)
                return NULL;
        }
        else if (line[i] == '\\' && line[i + 1] != '\0')
            handle_escape(&t, line[++i]);
        else
            t.buffer[t.buf_index++] = line[i];
        i++;
    }

    if (add_token(&t) == -1)
        return NULL;

    return t.tokens;
}