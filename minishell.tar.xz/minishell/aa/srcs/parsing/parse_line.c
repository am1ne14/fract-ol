#include "../../inc/minishell.h"

/*
int    parse_line(t_shell *data, char *line);

*/

int    parse_line(t_shell *data, char *line)
{
    char    **tokens;

    if (preprocess_line(line))
        return (1);

    tokens = tokenize(line);
    if (!tokens)
        return (1);

    data->command_list = parse_commands(tokens, data->env);
    free_tokens(tokens);

    return (0);
}
