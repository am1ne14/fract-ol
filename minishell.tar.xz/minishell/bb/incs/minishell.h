#ifndef MINISHELL_H
#define MINISHELL_H

// #include "parsing.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h>
#include <signal.h>
#include <readline/readline.h>
#include <readline/history.h>


typedef struct s_env
{
    char        *key;
    char        *value;
    struct s_env    *next;
}   t_env;



typedef struct  s_command
{
    char    **argv;            
    char    **cmd_path;         
    int     input_fd;           
    int     output_fd;          
    struct s_command *next;     
}   t_command;


typedef struct s_shell
{
    t_env           *env;               
    t_command       *command_list;
    bool            is_running;    
    int             last_exit_code;
}   t_shell;

//signals
void    signals_setup(void);
void    sigint_handler(int sig);
void    sigsegv_handler(int sig);
void    sigabrt_handler(int sig);

//general_utils
void	clear_rl_line(void);
char *ft_strndup(const char *s, size_t n);

//init_data.c
void    init_data(t_shell *data);
t_env   *init_env(char **env);

///////////////////////PARSING
int    parse_line(t_shell *data, char *line);
//////PREPROCESSING
int    preprocess_line(char *line);
int     check_invalid_start(char *line);
int    check_unclosed_quotes(char *line);
int    check_consecutive_operators(char *line);
//////TOKENISATION
char    **tokenize(char *line);
int     process_tokens(char **raw_tokens, char **tokens, int *i);
char    *remouve_quotes(char *token);
/////PARSE_COMMAND
t_command   *parse_commands(char **tokens, t_env *env);
t_command   *create_command_node(void);
t_command	*create_next_command(t_command *current, int *i);
void	    process_token(t_command *cmd, char **tokens, int *i, t_env *env);
void	handle_redirection(t_command *cmd, char **tokens, int *i);
//parsing _helpers
char    *trim_white_spaces(char *str);
int     array_size(char **array);
int     is_special_char(char c);
int     is_pipe(char *token);
int	    is_redirection(char *token);
char	**add_to_array(char **array, char *str);
int     ft_isalnum(int c);
size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize);

// ennviremt _utils.c
void	add_argument(t_command *cmd, char *token, t_env *env);
char	*expand_env_var(char *token, t_env *env);
char	*get_env_value(t_env *env, const char *key);
char	*get_key(const char *token);

//free_utils
void    free_env(t_env *env);
void    free_commands(t_command *cmd_list);
void    free_data(t_shell *data);
void    free_tokens(char **token);
void    free_command_list(t_command *command_list);

//tmp
char	**ft_split(const char *s, char delimiter);
void    print_array(char **token);

#endif