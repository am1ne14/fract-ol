#include "../../incs/minishell.h"
/*
char    **tokenize(char *line);
int     process_tokens(char **raw_tokens, char **tokens, int *i);
char    *remouve_quotes(char *token);
*/

char    **tokenize(char *line)
{
    char    **raw_tokens;
    char    **tokens;
    int     count;
    int     i;
    raw_tokens = ft_split(line, ' ' );
    if (!raw_tokens)
        return NULL;
    count = array_size(raw_tokens);
    tokens = malloc(sizeof(char *) * (count + 1));
    if (!tokens)
        return NULL;
    i = 0;
    while (raw_tokens[i])
    {
        if (!process_tokens(raw_tokens, tokens, &i))
        {
            free(raw_tokens);
            return (NULL);
        }
    }
    tokens[i] = NULL;
    free(raw_tokens);
    return (tokens);
}

int process_tokens(char **raw_tokens, char **tokens, int *i)
{
    char *cleaned;

    cleaned = NULL;
    if (is_special_char(raw_tokens[*i][0]))
        tokens[*i] = strdup(raw_tokens[*i]);
    else
        tokens[*i] = remouve_quotes(raw_tokens[*i]);
    if (!tokens[*i])
        return (0);
    free(raw_tokens[*i]);
    (*i)++;
    return (1);
}

char    *remouve_quotes(char *token)
{
    char    *clened_token;
    int     len;

    len = strlen(token);
    if ((token[0] == '"' || token[0] == '\'') && token[len - 1] == token[0])
    {
        clened_token = ft_strndup(token + 1, len -2);
        return (clened_token);
    }
    return (strdup(token));
}
