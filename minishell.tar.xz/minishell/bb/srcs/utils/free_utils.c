#include "../../incs/minishell.h"

/*
void    free_env(t_env *env);
void    free_commands(t_command *cmd_list);
void    free_data(t_shell *data);
void    free_tokens(char **token);
void    free_command_list(t_command *command_list);
*/

void free_env(t_env *env)
{
    t_env *tmp;

    while (env)
    {
        tmp = env->next;
        if (env->key)
            free(env->key);
        if (env->value)
            free(env->value);
        free(env);
        env = tmp;
    }
}

void free_commands(t_command *cmd_list)
{
    t_command *tmp;
    int i;

    while (cmd_list)
    {
        tmp = cmd_list->next;
        if (cmd_list->argv)
        {
            i = 0;
            while (cmd_list->argv[i])
            {
                free(cmd_list->argv[i]);
                i++;
            }
            free(cmd_list->argv);
        }
        if (cmd_list->cmd_path)
            free(cmd_list->cmd_path);
        free(cmd_list);
        cmd_list = tmp;
    }
}


void free_data(t_shell *data)
{
    if (data->env)
        free_env(data->env);
    if (data->command_list)
        free_commands(data->command_list);
}

void    free_tokens(char **token)
{
    int     i;

    i = 0;
    if (!token)
        return ;
    while (token[i])
        free(token);
    free(token);
}

void free_command_list(t_command *command_list)
{
    t_command *temp;

    while (command_list)
    {
        temp = command_list;
        command_list = command_list->next;

        if (temp->argv)
        {
            for (int i = 0; temp->argv[i]; i++)
                free(temp->argv[i]);
            free(temp->argv);
        }

        if (temp->cmd_path)
            free(temp->cmd_path);
        free(temp);
    }
}