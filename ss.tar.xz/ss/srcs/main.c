#include "../inc/minishell.h"

int	main(int ac, char **av, char **env)
{
	t_shell	data;
	char	*line;

	(void)ac;
	(void)av;
	init_data(&data);
	data.env = init_env(env);
	if (!data.env)
	{
		printf("Error :Failed to initalise envirement variables");
		return(EXIT_FAILURE);
	}
	signals_handeling();
	while (true)
	{
		//printf("%s", data.env->key);
		line = readline("minishell$ ");
		if (!line)
		{
			free_data(&data);
			printf("exit\n");
			exit(EXIT_FAILURE);
		}
		if (*line == '\0')
		{
			free(line);
			continue ;
		}
		add_history(line);
		if (!parse_line(&data, line))
		{
			free(line);
			continue ;
		}
		// if (!exec(&data))
		// {
		// 	printf("Error: Command execution failed");
		// 	free(line);
		// 	free_data(&data);
		// 	exit(EXIT_FAILURE);
		// }
		free(line);
	}
	rl_clear_history();
	free_data(&data);
	return(EXIT_FAILURE);
}

// int main(void)
// {
//     // Simulate tokens
//     char **tokens = malloc(sizeof(char *) * 4);
//     tokens[0] = strdup("ls");
//     tokens[1] = strdup("-l");
//     tokens[2] = strdup("|");
//     tokens[3] = NULL;

//     // Simulate command list
//     t_command *command_list = malloc(sizeof(t_command));
//     command_list->argv = malloc(sizeof(char *) * 3);
//     command_list->argv[0] = strdup("ls");
//     command_list->argv[1] = strdup("-l");
//     command_list->argv[2] = NULL;
//     command_list->cmd_path = strdup("/bin/ls");
//     command_list->next = NULL;

//     // Free tokens
//     free_tokens(tokens);

//     // Free command list
//     free_command_list(command_list);

//     printf("Memory freed successfully!\n");
//     return 0;
// }