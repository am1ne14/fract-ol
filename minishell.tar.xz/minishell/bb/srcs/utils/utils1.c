#include "../../incs/minishell.h"
/*
void	clear_rl_line(void);
char *ft_strndup(const char *s, size_t n);

*/

void	clear_rl_line(void)
{
	rl_replace_line("", 0);
	rl_on_new_line();
}

char *ft_strndup(const char *s, size_t n)
{
    char *dup;
    size_t len;

    len = strnlen(s, n);
    dup = malloc(len + 1);
    if (!dup)
        return (NULL);
    memcpy(dup, s, len);
    dup[len] = '\0';
    return (dup);
}