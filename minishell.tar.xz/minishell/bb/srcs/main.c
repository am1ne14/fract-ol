#include "../incs/minishell.h"

int	main(int ac, char **av, char **env)
{
	t_shell	data;
	char	*line;

	(void)ac;
	(void)av;
	init_data(&data);
	data.env = init_env(env);
	if (!data.env)
	{
		printf("Error :Failed to initalise envirement variables");
		return(EXIT_FAILURE);
	}
	signals_setup();
	while (true)
	{
		line = readline("minishell$ ");
		if (!line)
		{
			free_data(&data);
			printf("exit\n");
			exit(EXIT_FAILURE);
		}
		if (*line == '\0')
		{
			free(line);
			continue ;
		}
		add_history(line);
		if (!parse_line(&data, line))
		{
			free(line);
			continue ;
		}
		// if (!exec(&data))
		// {
		// 	printf("Error: Command execution failed");
		// 	free(line);
		// 	free_data(&data);
		// 	exit(EXIT_FAILURE);
		// }
		free(line);
	}
	rl_clear_history();
	free_data(&data);
	return(EXIT_FAILURE);
}