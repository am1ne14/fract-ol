#include "../inc/minishell.h"

void    init_data(t_shell *data)
{
    if (!data)
        return ;
    data->env = NULL;
    data->command_list = NULL;
    data->is_running = true;
    data->last_exit_code = 0;
}


//strdup && strchr from stdio !!!
t_env*   init_env(char **env)
{
    t_env   *head = NULL;
    t_env   *current = NULL;
    t_env   *new_node;
    t_env   *equal_sign;

    while (*env)
    {
        equal_sign = strchr(*env, '=');
        if (!equal_sign)
        {
            env++;
            continue;
        }
        new_node = malloc(sizeof(t_env));
        if (!new_node)
            return (NULL); // return what ??
        new_node->key = strdup(*env, equal_sign - *env);
        new_node->value = strdup(equal_sign + 1);
        if (!head)
            head = new_node;
        else
            current->next = new_node;
        current = new_node;
        env++;
    }
    return(head);
}