#include "../../incs/minishell.h"

/*
void    signals_setup(void);
void    sigint_handler(int sig);
void    sigsegv_handler(int sig);
void    sigabrt_handler(int sig);
*/

void    signals_setup(void)
{
    signal(SIGINT, &sigint_handler);   
    signal(SIGSEGV, &sigsegv_handler);
    signal(SIGABRT, &sigabrt_handler);
    signal(SIGQUIT, SIG_IGN);
}


void    sigint_handler(int sig)
{
    (void)sig;
    write(1,"\n", 1);
    clear_rl_line();
    rl_redisplay();    
}

void    sigsegv_handler(int sig)
{
	(void)sig;
	write(2, "Segmentation fault\n", 19);
	exit(EXIT_FAILURE);
}

void    sigabrt_handler(int sig)
{
	(void)sig;
	write(1, "abort\n", 6);
}