#ifndef MINI_SHELL_H
#define MINI_SHELL_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h>
#include <signal.h>
#include <readline/readline.h>
#include <readline/history.h>

#define BUFFER_SIZE 1024

typedef struct s_tokenizer // norminette
{
    char buffer[BUFFER_SIZE];
    int buf_index;
    char **tokens;
    int token_count;
    char quote;
}   t_tokenizer;


    //struct for every single envirement variable
typedef struct s_env
{
    char        *key;       //name of the env variable
    char        *value;     //value of  ^^
    struct s_env    *next;  //point to next env variable (linked list)
}   t_env;


    //struct to parse commands and its arguments
typedef struct  s_command
{
    char **argv;            
    char    **cmd_path;         // full path of the executable binary of the command inputed 
    int     input_fd;           // (redirection)
    int     output_fd;          //    --
    struct s_command *next;     //pointer of the next argument if they use | (linked list)
}   t_command;


// main struct for the whole shell session 
typedef struct s_shell
{
    t_env   *env;               //linked llist of the env variables
    t_command   *command_list;  //linked list of the parsed commands
    bool    is_running;         // is the shell still running 
    int     last_exit_code;     // exit_code of the last runned command
}   t_shell;

//signals
void    signals_handeling(void);
void    sigint_handler(int sig);
void    sigsegv_handler(int sig);
void    sigabrt_handler(int sig);
void	clear_rl_line(void);

//init main!!
void    init_data(t_shell *data);
t_env*  init_env(char **env);

//parsing input line
int    parse_line(t_shell *data, char *line);
        // preprocessing
int    preprocess_line(char *line);
int    check_invalid_start(char *line);
char    *trim_white_spaces(char *str);
int    check_invalid_start(char *line);
int    check_unclosed_quotes(char *line);
int    check_consecutive_operators(char *str);
        //tokenization
char    **tokenize(char *line);
int     build_command_list(data, tokens);
int     validate_command_list(t_command *cmd_list);


//helpers
char    *ft_strndup(const char *s, size_t n);
void    free_data(t_shell *data);
void    free_commands(t_command *cmd_list);
void    free_env(t_env *env);
void    free_tokens(char **token);
void    free_command_list(t_command *command_list);

#endif