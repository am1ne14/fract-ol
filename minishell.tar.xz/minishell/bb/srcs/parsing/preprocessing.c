#include "../../incs/minishell.h"

/*
int    preprocess_line(char *line);
int     check_invalid_start(char *line);
int    check_unclosed_quotes(char *line);
int    check_consecutive_operators(char *line);

*/

int    preprocess_line(char *line)
{
    line = trim_white_spaces(line);

    if (check_invalid_start(line))
    {
        printf("Error: Invalid syntax \n");
        return (1); 
    }
    if (check_unclosed_quotes(line))
    {
        printf("Error: unclosed quotes in input\n");
        return (1);
    }
    if (check_consecutive_operators(line))
    {
        printf("Error: Invalid syntax - consecutive operators found\n");
        return (1);
    }

    return (0);
}

int check_invalid_start(char *line)
{
    int i = 0;
    if (line[0] == '|' || line[0] == '<' || line[0] == '>' || line[0] == '&')
        return (1);
    while (line[i])
        i++;
    if (line[i -1] == '|' || line[i - 1] == '<' || line[i -1 ] == '>' || line[i - 1] == '&')
        return (1);
    return (0);
}

int    check_unclosed_quotes(char *line)
{
    char    quote;

    quote = '\0';
    while (*line)
    {
        if ((*line == '\'' || *line == '\"') && quote == '\0')
            quote = *line;
        else if (*line == quote)
            quote = '\0';
        line++;
    }
    return (quote != '\0');
}

int    check_consecutive_operators(char *line)
{
    while (*line)
    {
        if ((*line == '|' || *line == '<' || *line == '>' || *line == '&' || *line == '|') &&
        (*(line + 1) == '|' || *(line + 1) == '>' || *(line + 1) == '<' || *(line + 1) == '&' || *(line + 1) == '|'))
        {
            return (1);
        }
        line++;
    }
    return (0);
}