#include "../inc/minishell.h"

void    init_data(t_shell *data)
{
    if (!data)
        return ;
    data->env = NULL;
    data->command_list = NULL;
    data->is_running = true;
    data->last_exit_code = 0;
}

char *ft_strndup(const char *s, size_t n)
{
    char *dup;
    size_t len;

    len = strnlen(s, n);
    dup = malloc(len + 1);
    if (!dup)
        return (NULL);
    memcpy(dup, s, len);
    dup[len] = '\0';
    return (dup);
}

t_env *init_env(char **env)
{
    t_env   *head = NULL;
    t_env   *current = NULL;
    t_env   *new_node;
    char    *equal_sign;

    while (*env)
    {
        equal_sign = strchr(*env, '=');
        if (!equal_sign)
        {
            env++;
            continue;
        }
        new_node = malloc(sizeof(t_env));
        if (!new_node)
            return (NULL);
        new_node->key = ft_strndup(*env, equal_sign - *env);
        new_node->value = strdup(equal_sign + 1);
        if (!new_node->key || !new_node->value)
        {
            free(new_node->key);
            free(new_node->value);
            free(new_node);
            return (NULL);
        }
        new_node->next = NULL;
        if (!head)
            head = new_node;
        else
            current->next = new_node;
        current = new_node;
        env++;
    }
    return (head);
}