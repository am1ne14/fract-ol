#include "../inc/minishell.h"

static void test_data(t_shell *data)
{
    while (data->env->key)
    {
        printf("%s :::: %s\n",data->env->key, data->env->value);
        data->env->key = data->env->next;
    }
}
int main(int ac, char **av, char **env)
{
    t_shell data;
    char *line;

    init_shell(&data, env); // done /utils/init_shell.c
    test_list(&data);
    while (1)
    {
        line = readline("minishell> ");
        if (!line)
        {
            printf("Exit\n");
            break;
        }
        if (*line)
        {
            add_history(line);
            if (parse_line(&data, line))
                printf("Error :line parsing failed\n");
            // else
            //     execute_commands(&data);
        }
        free(line);
    }
    // clean_setup(&data);
    return (0);
}

